package com.pratwib.animaze.ui.theme

import androidx.compose.ui.graphics.Color

val Yellow200 = Color(0xFFFFF59D)
val Yellow500 = Color(0xFFFFEB3B)
val Yellow800 = Color(0xFFF9A825)
val Red200 = Color(0xFFEF9A9A)