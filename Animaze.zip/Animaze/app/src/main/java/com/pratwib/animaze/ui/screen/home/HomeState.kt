package com.pratwib.animaze.ui.screen.home

data class HomeState(
    val query: String = ""
)